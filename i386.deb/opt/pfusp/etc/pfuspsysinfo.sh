#!/bin/sh

LOGFILENAME=pfuspsysinfo.txt
LOGPATH=/var/log/pfusp
WORKFOLDER=$(pwd)
CURRENTDATE=`date -d "today" +"%Y%m%d_%H%M%S"`
FileName=pfusplog${CURRENTDATE}.tar.gz

DoCollectSystemLog()
{
  if [ -f $LOGFILENAME ]; then
    rm $LOGFILENAME 2>/dev/null
  fi
  echo "----- system information -----" >>$LOGFILENAME
  date >> $LOGFILENAME
  uname -a >> $LOGFILENAME
  if [ -f /etc/lsb-release ]; then
    cat /etc/lsb-release >> $LOGFILENAME 2>&1
  fi
  echo "----- cpu and memory information -----" >>$LOGFILENAME
  cat /proc/cpuinfo >> $LOGFILENAME 2>&1
  cat /proc/meminfo >> $LOGFILENAME 2>&1
  echo "----- usb device information -----" >>$LOGFILENAME
  lsusb >> $LOGFILENAME 2>&1
  lsusb -v >> $LOGFILENAME 2>&1
  echo "----- pci information -----" >>$LOGFILENAME
  lspci >> $LOGFILENAME 2>&1
  echo "----- dmesg information -----" >>$LOGFILENAME
  dmesg >> $LOGFILENAME 2>&1
  echo "----- syslog information -----" >>$LOGFILENAME
  cat /var/log/syslog >> $LOGFILENAME 2>&1
  echo "----- file information -----" >>$LOGFILENAME
  lsof /dev >> $LOGFILENAME 2>&1
}

DoZip()
{
  if [ -d $LOGPATH ]; then
    cp $LOGFILENAME $LOGPATH 2>/dev/null
    cd $LOGPATH 2>/dev/null
    tar -czf  $WORKFOLDER/$FileName * 2>/dev/null || {
        echo "It is failed to collect logs." > /dev/tty
        kill -15 $$
    }
    if [ -f ./$LOGFILENAME ]; then
      rm -f ./$LOGFILENAME 2>/dev/null
    fi
    cd $WORKFOLDER 2>/dev/null
  else
    tar -czf  $FileName $LOGFILENAME 2>/dev/null || {
        echo "It is failed to collect logs." > /dev/tty
        kill -15 $$
    }
  fi
}

if [ `id -u` -eq 0 ]; then
    DoCollectSystemLog&

    COLLECTLOGPID=$!

    while true
    do
        ps -p ${COLLECTLOGPID} > /dev/null
        if [ $? -eq 0 ]; then
            printf "."
            sleep 1
        else
            break
        fi
    done

    if ( DoZip | ( while read a; do printf "."; done; echo; ) ); then
        echo "It is successful to collect logs."
    fi
else
    echo "Permission denied."
fi
